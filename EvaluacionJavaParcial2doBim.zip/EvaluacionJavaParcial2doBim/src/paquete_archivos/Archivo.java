package paquete_archivos;



// Fig. 14.11: LeerArchivoTexto.java
// Este programa lee un archivo de texto y muestra cada registro.

import modelado.Participante;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.IllegalStateException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import java.util.ArrayList;


import com.google.gson.Gson;

public class Archivo {

    private Scanner entrada;

    // permite al usuario abrir el archivo
    public void abrirArchivo(String nombreArchivo) {
        try {
            // entrada va a tener cargado todo el archivo
            entrada = new Scanner(new File(nombreArchivo));
        } // fin de try
        catch (FileNotFoundException fileNotFoundException) {
            System.err.println("Error al abrir el archivo.");
            System.exit(1);
        } // fin de catch
    } // fin del m�todo abrirArchivo

    // lee registro del archivo
    
    public ArrayList<Participante> leerJson() {

      
        ArrayList<Participante> listaProfesores = new ArrayList<>();

        try // lee registros del archivo, usando el objeto Scanner
        {
            entrada.nextLine();
            while (entrada.hasNext()) {
                // se crea el objeto para leer Json
                Gson g = new Gson();
                String linea = entrada.nextLine();
                // se hace el proceso de transformación
                Participante p = g.fromJson(linea, Participante.class);
                listaProfesores.add(p);
                //System.out.println(p);

            } // fin de while

        } // fin de try // fin de try
        catch (NoSuchElementException elementException) {
            System.err.println("El archivo no esta bien formado.");
            entrada.close();
            System.exit(1);
        } // fin de catch
        catch (IllegalStateException stateException) {
            System.err.println("Error al leer del archivo.");
            System.exit(1);
        } // fin de catch
        return listaProfesores;
    } // fin del m�todo leerRegistros
    // cierra el archivo y termina la aplicaci�n

    // Metodo para leer el archivo csv
    public ArrayList<Participante> leerCsv(){

        ArrayList<Participante> listaProfesores = new ArrayList<>();
        try // lee registros del archivo, usando el objeto Scanner
        {
            entrada.nextLine();
            
            // Se crea una lista donde se guardaran los datos de la line leida
            String[] lista = new String[8];
            while (entrada.hasNext()) {
                          
                // entrada ira leyendo linea por linea
                String linea = entrada.nextLine();
                lista = linea.split(",");
                
                // Se agregan los datos a un objeto persona
                Participante p = new Participante(lista[0],lista[1],lista[2],lista[3],lista[4],lista[5],lista[6],lista[7]);
                
                // Se agrega el objeto a la lista
                listaProfesores.add(p);
                
            } // fin de while

        } // fin de try
        catch (NoSuchElementException elementException) {
            System.err.println("El archivo no esta bien formado.");
            entrada.close();
            System.exit(1);
        } // fin de catch
        catch (IllegalStateException stateException) {
            System.err.println("Error al leer del archivo.");
            System.exit(1);
        } // fin de catch
        
        return listaProfesores;
    }
    
   
    
    public void cerrarArchivo() {
        if (entrada != null) {
            entrada.close(); // cierra el archivo
        }
    } // fin del m�todo cerrarArchivo
} // fin de la clase LeerArchivoTexto

