package main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import paquete_archivos.Archivo;
import modelado.Participante;
import modelado.OperacionData;
import java.util.ArrayList;

public class Principal {

    public static void main(String args[]) throws IOException {

        // * Creamos una lista en la que se guardaran todos los objetos Participante que se lean
        ArrayList<Participante> listaParticipantes = new ArrayList<>();

        // * Creamos un objeto archivo para cada conjunto de datos
        Archivo data1 = new Archivo();
        data1.abrirArchivo("data/data1.csv");
        Archivo data2 = new Archivo();
        data2.abrirArchivo("data/data2.txt");

        // * Obtenemos la inforacion de los archivos y los convertimos en listas
        listaParticipantes = data1.leerCsv();                                  // Leemos los datos del primer archivo
        listaParticipantes.addAll(data2.leerJson());                           // Le agregamos a la lista principal los datos del segundo archivo

        // * Ahora ya tenemos la listaParticipantes con todos los objetos Participante
        // Instanciamos un objeto operaciones
        OperacionData operar = new OperacionData();
        operar.agregarInformacion(listaParticipantes);

        // * Imprimir un listado de los participantes ordenados por cantón
        ArrayList<Participante> listaPorCanton = operar.ordenarPorCanton();
        System.out.println("Imprimimos todos los participantes ordenados por cantones");
        operar.showData(listaPorCanton); // Imprimira los objetos ordenados por canton

        // Generar un archivo de los participantes ordenados por nombres y apellidos
        //Crear un objeto File se encarga de crear o abrir acceso a un archivo que se especifica en su constructor
        // Escribimos con el metodo write de la clase PrintWriter
        //Crear objeto FileWriter que sera el que nos ayude a escribir sobre archivo
        File archivoSalida = new File("data/data3.txt");
        FileWriter data3 = new FileWriter(archivoSalida);
        
        // Escribimos con el metodo write de la clase FileWriter
        ArrayList<Participante> listaPorNombres = operar.ordenarPorNombres();
        for (int i = 0; i < listaPorNombres.size(); i++) {
            data3.write(listaPorNombres.get(i).toString() + "\n");
        }
        System.out.println("\n\nArchivo con los participantes ordenados por nombres escrito con éxito!\n\n");

        // *  Obtener cuantos Participantes de acuerdo a la característica personalidad, están catalogados como "ADECUADO" o "POR CONVOCAR"
        // Como "Adecuado"
        System.out.printf("\nNumero de particpantes de acuerdo a la característica personalidad catalogados como 'ADECUADO': %d \n", operar.getNumberOf("personalidad", "ADECUADO"));

        // Co(mo "Por convocar"
        System.out.printf("Numero de particpantes de acuerdo a la característica personalidad catalogados como 'POR CONVOCAR': %d \n", operar.getNumberOf("personalidad", "POR CONVOCAR"));

        //Obtener cuantos Participantes de acuerdo a la característica DICTAMENDEIDONEIDAD, están catalogados como "IDONEO" o "NO IDONEO"
        // Como "Idoneo"
        System.out.printf("Numero de particpantes de acuerdo a la característica dictamenidoniedad catalogados como 'IDONEO': %d \n", operar.getNumberOf("dictamenIdoniedad", "IDONEO"));

        // Como "No idoneo"
        System.out.printf("Numero de particpantes de acuerdo a la característica dictamenidoniedad catalogados como 'NO IDONEO': %d \n", operar.getNumberOf("dictamenIdoniedad", "NO IDONEO"));

        // Total de particpantes
        System.out.printf("\nTOTAL DE PARTICIPANTES: %d\n\n", listaParticipantes.size());

        // Cerramos los archivos
        data1.cerrarArchivo();
        data2.cerrarArchivo();
        data3.close();

    } // fin de main

} // fin de la clase Principal

