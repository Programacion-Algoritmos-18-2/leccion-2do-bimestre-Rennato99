package modelado;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author reroes
 */
public class OperacionData {

    ArrayList<Participante> informacion = new ArrayList<>();

    public void agregarInformacion(ArrayList<Participante> info) {

        informacion = info;
    }

    // Metodo que retorna la informacion cargada del objeto
    public ArrayList<Participante> obtenerInformacion() {
        return informacion;
    }

    public double obtenerPromedioCapacidad() {
        double suma = 0;
        return suma;
    }

    // proceso de ordenar, a través del uso de Collections
    public ArrayList<Participante> ordenarPorCanton() {
        ArrayList<Participante> dataPorCantones = new ArrayList<>();
        dataPorCantones.addAll(informacion);
        Collections.sort(dataPorCantones,
                (o1, o2) -> o1.canton.compareTo(o2.canton));
        return dataPorCantones;

    }

    // Metodo que ordena por nombres, a traves de Collections
    public ArrayList<Participante> ordenarPorNombres() {
        ArrayList<Participante> dataPorNombres = new ArrayList<>();
        dataPorNombres.addAll(informacion);
        Collections.sort(dataPorNombres,
                (o1, o2) -> o1.nombres.compareTo(o2.nombres));
        return dataPorNombres;

    }

    // Metodo para presentaar la informacion de una manera ordenada
    public void showData(ArrayList data) {
        for (int i = 0; i < data.size(); i++) {
            System.out.println(data.get(i));
        }

    }

    // 	# Metodo para obtener cuantos elementos hay de acuerdo a algun parametro | el primer atributo es la columna y el segundo lo que debe tener la columna para que cuente
    public int getNumberOf(String atributo, String condicion) {
        int suma = 0; // Inicializamos un cocntador en 0
            
        if ("personalidad".equals(atributo)){
            // Recorremos la lista
            for(int i = 0; i < informacion.size(); i++){
                // Si cumple la condicion se suma
		if (informacion.get(i).getPersonalidad().equals(condicion)){
                    suma += 1;

                }
            }
        }

	if ("dictamenIdoniedad".equals(atributo)){
            // Recorremos la lista
            for(int i = 0; i < informacion.size(); i++){
		// Si cumple la condicion se suma
		if (informacion.get(i).getDictamenIdoniedad().equals(condicion)){
                    suma += 1;

                }
            }
        }
        
        return suma;
    }

}
